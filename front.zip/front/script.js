// Se o front não for servido pelo Express (porta 3000), fala com a API direto.
const API =
  window.API_URL ?? (location.port === '3000' ? '' : 'http://localhost:3000')
const ESTOQUE_BAIXO = 5
const reduzMovimento = matchMedia('(prefers-reduced-motion: reduce)').matches

const $ = (seletor) => document.querySelector(seletor)
const $$ = (seletor) => [...document.querySelectorAll(seletor)]
const estado = {
  produtos: [],
  carregado: false,
  token: null,
  usuario: null,
  editandoId: null,
  carrinho: new Map(), // produtoId -> quantidade
  pedidos: [],
  aba: 'carrinho',
  finalizado: false,
  erroCarrinho: '',
  filtros: { categoria: '', destaque: false, baixo: false },
}
const ehAdmin = () => estado.usuario?.tipo === 'admin'

// ---------- utilidades ----------
// Cria elementos com textContent (nunca innerHTML), então dados do banco não injetam HTML.
function h(tag, props = {}, ...filhos) {
  const el = document.createElement(tag)
  for (const [chave, valor] of Object.entries(props)) {
    if (chave === 'class') el.className = valor
    else if (chave.startsWith('on')) el.addEventListener(chave.slice(2), valor)
    else el.setAttribute(chave, valor)
  }
  el.append(...filhos)
  return el
}

// Ícones fixos (texto escrito aqui no código, nunca vindo do banco).
const traco = (d) =>
  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`
const SVG = {
  ok: traco('<path d="M5 12.5l4.5 4.5L19 7.5"/>'),
  erro: traco(
    '<circle cx="12" cy="12" r="9"/><path d="M12 7.5v5.5M12 16.5h.01"/>',
  ),
  info: traco(
    '<circle cx="12" cy="12" r="9"/><path d="M12 11v5.5M12 7.5h.01"/>',
  ),
  sol: traco(
    '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  ),
  lua: traco('<path d="M20 14.5A8 8 0 019.5 4 8 8 0 1020 14.5z"/>'),
  pacote: traco(
    '<path d="M21 8l-9-5-9 5 9 5 9-5z"/><path d="M3 8v8l9 5 9-5V8M12 13v8"/>',
  ),
  fogo: traco(
    '<path d="M12 3c1 3.5 5 5.5 5 10a5 5 0 01-10 0c0-2 1-3.2 2-4 .2 1.5 1 2.3 2 2.5C11 9 11 6 12 3z"/>',
  ),
  alerta: traco(
    '<path d="M12 3l10 18H2L12 3z"/><path d="M12 10v5M12 18h.01"/>',
  ),
  moeda: traco(
    '<circle cx="12" cy="12" r="9"/><path d="M14.5 9.2c-.5-.8-1.5-1.2-2.6-1.2-1.5 0-2.6.8-2.6 2s1 1.7 2.7 2c1.7.3 2.7.8 2.7 2s-1.1 2-2.7 2c-1.2 0-2.2-.5-2.7-1.3M12 6.5V8M12 16v1.5"/>',
  ),
  olho: traco(
    '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  ),
  olhoFechado: traco(
    '<path d="M3 3l18 18M10.6 5.1A9.7 9.7 0 0112 5c6.5 0 10 7 10 7a17 17 0 01-3.2 4M6.5 6.6A17 17 0 002 12s3.5 7 10 7c1.7 0 3.2-.4 4.5-1M9.9 9.9a3 3 0 004.2 4.2"/>',
  ),
  lupa: traco('<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>'),
  mais: traco('<path d="M12 5v14M5 12h14"/>'),
  menos: traco('<path d="M5 12h14"/>'),
  lapis: traco('<path d="M4 20l1-4L16.5 4.5a2 2 0 013 3L8 19l-4 1z"/>'),
  lixo: traco('<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>'),
  carrinho: traco(
    '<circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2 3h3l2.4 11.2a1 1 0 001 .8h9.2a1 1 0 001-.8L20 7H6"/>',
  ),
  recibo: traco('<path d="M6 3h12v18l-3-2-3 2-3-2-3 2V3z"/><path d="M9 8h6M9 12h6"/>'),
  relogio: traco('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'),
  cartao: traco('<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/>'),
  caminhao: traco(
    '<path d="M2 6h11v10H2zM13 9h4l3 3v4h-7"/><circle cx="6" cy="18" r="1.7"/><circle cx="17" cy="18" r="1.7"/>',
  ),
  x: traco('<path d="M6 6l12 12M18 6L6 18"/>'),
  refazer: traco('<path d="M3 12a9 9 0 0115.5-6.2L21 8M21 3v5h-5M21 12a9 9 0 01-15.5 6.2L3 16M3 21v-5h5"/>'),
  copiar: traco('<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 012-2h9"/>'),
}
function icone(nome) {
  const el = h('span', { class: 'ico' })
  el.innerHTML = SVG[nome]
  return el
}
$$('[data-ico]').forEach((el) => {
  el.classList.add('ico')
  el.innerHTML = SVG[el.dataset.ico]
})

const dinheiro = (n) =>
  n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
const dinheiroCurto = (n) =>
  n.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    maximumFractionDigits: 0,
  })
const normalizar = (t) =>
  t
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()

// Cada categoria ganha sempre a mesma cor (matiz), calculada a partir do nome.
function matizDaCategoria(nome) {
  let hash = 0
  for (const letra of nome) hash = (hash * 31 + letra.charCodeAt(0)) % 360
  return hash
}

// Anima um número de onde ele estava até o novo valor.
function contar(seletor, destino, formatar = (n) => String(Math.round(n))) {
  const el = $(seletor)
  const de = Number(el.dataset.v ?? 0)
  el.dataset.v = destino
  const id = (el._anim = (el._anim || 0) + 1)
  if (reduzMovimento || de === destino) {
    el.textContent = formatar(destino)
    return
  }
  const inicio = performance.now()
  const passo = (agora) => {
    if (el._anim !== id) return
    const t = Math.min((agora - inicio) / 700, 1)
    el.textContent = formatar(de + (destino - de) * (1 - Math.pow(1 - t, 3)))
    if (t < 1) requestAnimationFrame(passo)
  }
  requestAnimationFrame(passo)
}

// Deixa o botão "carregando" (e guarda o texto original para voltar).
function ocupado(botao, sim, texto) {
  const rot = botao.querySelector('.rot') ?? botao
  if (sim) {
    botao.dataset.rot = rot.textContent
    rot.textContent = texto
  } else if (botao.dataset.rot) {
    rot.textContent = botao.dataset.rot
    delete botao.dataset.rot
  }
  botao.disabled = sim
  botao.classList.toggle('carregando', sim)
}

// ---------- avisos ----------
function toast(texto, tipo = 'ok', acao = null) {
  const duracao = acao ? 7000 : 4000
  let timer
  const fechar = () => {
    clearTimeout(timer)
    item.classList.add('saindo')
    setTimeout(() => item.remove(), 200)
  }
  const item = h(
    'div',
    {
      class: `toast t-${tipo}`,
      role: tipo === 'erro' ? 'alert' : 'status',
      style: `--dur:${duracao}ms`,
    },
    icone(tipo),
    h('p', {}, texto),
    acao
      ? h(
          'button',
          {
            type: 'button',
            class: 'toast-acao',
            onclick: () => {
              acao.fn()
              fechar()
            },
          },
          acao.rotulo,
        )
      : '',
    h(
      'button',
      {
        type: 'button',
        class: 'toast-x',
        'aria-label': 'Fechar aviso',
        onclick: fechar,
      },
      '×',
    ),
    h('span', { class: 'toast-barra' }),
  )
  $('#toasts').append(item)
  timer = setTimeout(fechar, duracao)
}

// ---------- tema ----------
function aplicarTema(tema) {
  document.documentElement.dataset.tema = tema
  localStorage.setItem('tema', tema)
  $('#btn-tema').innerHTML = SVG[tema === 'dark' ? 'sol' : 'lua']
}
$('#btn-tema').addEventListener('click', () =>
  aplicarTema(
    document.documentElement.dataset.tema === 'dark' ? 'light' : 'dark',
  ),
)
aplicarTema(document.documentElement.dataset.tema === 'dark' ? 'dark' : 'light')

// ---------- sessão ----------
// O token (JWT) já carrega nome, email e tipo do usuário; é dele que tiramos os dados.
function lerToken(token) {
  try {
    const base64 = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')
    const json = decodeURIComponent(
      atob(base64)
        .split('')
        .map((c) => '%' + c.charCodeAt(0).toString(16).padStart(2, '0'))
        .join(''),
    )
    return JSON.parse(json)
  } catch {
    return null
  }
}
function usuarioDoToken(token) {
  const dados = token && lerToken(token)
  return dados
    ? { nome: dados.nome, email: dados.email, tipo: dados.tipo }
    : null
}
function restaurarSessao() {
  localStorage.removeItem('usuario') // guardado por versões antigas do front
  const token = localStorage.getItem('token')
  const dados = token && lerToken(token)
  if (!dados || (dados.exp && dados.exp * 1000 < Date.now())) {
    localStorage.removeItem('token')
    return
  }
  estado.token = token
  estado.usuario = usuarioDoToken(token)
}

async function api(caminho, opcoes = {}) {
  const ehLogin = caminho === '/login'
  const headers = { 'Content-Type': 'application/json' }
  if (estado.token && !ehLogin) headers.Authorization = `Bearer ${estado.token}`
  if (ehAdmin()) headers.admin = 'true'

  let resposta
  try {
    resposta = await fetch(API + caminho, { ...opcoes, headers })
  } catch {
    throw new Error('Não consegui falar com o servidor. Ele está rodando?')
  }
  const dados = await resposta.json().catch(() => ({}))

  if (resposta.status === 401 && estado.token && !ehLogin) {
    sair()
    throw new Error('Sua sessão expirou. Entre de novo.')
  }
  if (!resposta.ok) throw new Error(dados.erro || 'Algo deu errado.')
  return dados
}

// ---------- lista ----------
const filtrosAtivos = () =>
  Boolean(
    $('#busca').value.trim() ||
    estado.filtros.categoria ||
    estado.filtros.destaque ||
    estado.filtros.baixo,
  )

function filtrados() {
  const busca = normalizar($('#busca').value.trim())
  const { categoria, destaque, baixo } = estado.filtros
  const ordens = {
    nome: (a, b) => a.nome.localeCompare(b.nome, 'pt-BR'),
    'preco-asc': (a, b) => a.preco - b.preco,
    'preco-desc': (a, b) => b.preco - a.preco,
    'estoque-asc': (a, b) => a.estoque - b.estoque,
  }
  return estado.produtos
    .filter((p) => normalizar(p.nome).includes(busca))
    .filter((p) => !categoria || p.categoria === categoria)
    .filter((p) => !destaque || p.vendeu_muito)
    .filter((p) => !baixo || p.estoque <= ESTOQUE_BAIXO)
    .sort(ordens[$('#ordem').value])
}

function limparFiltros() {
  $('#busca').value = ''
  Object.assign(estado.filtros, {
    categoria: '',
    destaque: false,
    baixo: false,
  })
  render()
}

// Uma etiqueta de produto. Em "preview", é só a pré-visualização do formulário.
function criarCard(p, { n = 0, preview = false } = {}) {
  const semEstoque = p.estoque == null
  const baixo = !semEstoque && p.estoque <= ESTOQUE_BAIXO
  const acesos = semEstoque ? 0 : Math.ceil(Math.min(p.estoque, 20) / 2)
  const textoEstoque = semEstoque
    ? 'Estoque não informado'
    : p.estoque === 0
      ? 'Esgotado'
      : baixo
        ? `Só ${p.estoque} em estoque`
        : `${p.estoque} em estoque`

  const card = h(
    'article',
    { class: baixo ? 'tag baixo' : 'tag' },
    h('span', { class: 'furo' }),
    p.vendeu_muito
      ? h('span', { class: 'selo' }, icone('fogo'), 'Vendeu muito')
      : '',
    h('p', { class: 'cat' }, p.categoria),
    h('h3', {}, p.nome),
    h('p', { class: 'preco' }, dinheiro(p.preco)),
    h(
      'div',
      { class: 'pips', 'aria-hidden': 'true' },
      ...Array.from({ length: 10 }, (_, i) =>
        h('i', i < acesos ? { class: 'on', style: `--i:${i}` } : {}),
      ),
    ),
    h('p', { class: 'estoque' }, textoEstoque),
  )
  card.style.setProperty('--h', matizDaCategoria(p.categoria))
  card.style.setProperty('--n', Math.min(n, 12))

  if (!preview) {
    card.dataset.id = p._id
    if (p._id === estado.editandoId) card.classList.add('em-edicao')
    const noCarrinho = estado.carrinho.get(p._id) ?? 0
    card.append(
      h(
        'div',
        { class: 'compra' },
        p.estoque === 0
          ? h('button', { type: 'button', class: 'sec', disabled: '' }, 'Esgotado')
          : noCarrinho
            ? controleQtd(p, noCarrinho)
            : h(
                'button',
                { type: 'button', class: 'comprar', onclick: () => adicionar(p) },
                icone('carrinho'),
                h('span', { class: 'rot' }, 'Adicionar'),
              ),
      ),
    )
    if (ehAdmin()) {
      const excluir = h(
        'button',
        { type: 'button', class: 'sec perigo' },
        icone('lixo'),
        h('span', { class: 'rot' }, 'Excluir'),
      )
      excluir.addEventListener('click', () => confirmarExclusao(excluir, p))
      card.append(
        h(
          'div',
          { class: 'admin' },
          h(
            'button',
            { type: 'button', class: 'sec', onclick: () => abrirProduto(p) },
            icone('lapis'),
            h('span', { class: 'rot' }, 'Editar'),
          ),
          excluir,
        ),
      )
    }
  }
  return card
}

function renderChips() {
  const contagem = new Map()
  for (const p of estado.produtos)
    contagem.set(p.categoria, (contagem.get(p.categoria) ?? 0) + 1)
  const nomes = [...contagem.keys()].sort((a, b) => a.localeCompare(b, 'pt-BR'))
  const chip = (nome, rotulo, qtd) => {
    const ativo = estado.filtros.categoria === nome
    return h(
      'button',
      {
        type: 'button',
        class: 'chip',
        'aria-pressed': String(ativo),
        onclick: () => {
          estado.filtros.categoria = ativo ? '' : nome
          render()
        },
      },
      nome
        ? h('span', { class: 'pto', style: `--h:${matizDaCategoria(nome)}` })
        : '',
      rotulo,
      h('span', { class: 'qtd' }, String(qtd)),
    )
  }
  $('#chips').replaceChildren(
    ...(nomes.length
      ? [
          chip('', 'Todas', estado.produtos.length),
          ...nomes.map((n) => chip(n, n, contagem.get(n))),
        ]
      : []),
  )
  $('#chips').hidden = nomes.length === 0
}

function render({ entrada = false } = {}) {
  const lista = filtrados()
  const total = estado.produtos.length
  const ativos = filtrosAtivos()

  renderChips()
  $('#st-destaque-btn').setAttribute(
    'aria-pressed',
    String(estado.filtros.destaque),
  )
  $('#st-baixo-btn').setAttribute('aria-pressed', String(estado.filtros.baixo))
  $('#btn-limpar').hidden = !ativos
  $('#resumo').replaceChildren(
    h(
      'strong',
      {},
      `${lista.length} de ${total} ${total === 1 ? 'produto' : 'produtos'}`,
    ),
    ativos ? ' com os filtros atuais.' : ' no estoque.',
  )

  const caixa = $('#lista')
  if (entrada) {
    caixa.classList.add('entrando')
    setTimeout(() => caixa.classList.remove('entrando'), 1400)
  }

  if (lista.length === 0) {
    const vazio = total === 0
    caixa.replaceChildren(
      h(
        'div',
        { class: 'aviso' },
        h(
          'strong',
          {},
          vazio ? 'Nenhum produto cadastrado' : 'Nenhum produto encontrado',
        ),
        vazio
          ? ehAdmin()
            ? 'Use o painel acima para cadastrar o primeiro.'
            : 'Entre como admin para cadastrar o primeiro.'
          : 'Tente outro nome ou limpe os filtros.',
        vazio
          ? ''
          : h(
              'div',
              {},
              h(
                'button',
                { type: 'button', class: 'sec', onclick: limparFiltros },
                'Limpar filtros',
              ),
            ),
      ),
    )
    return
  }
  caixa.replaceChildren(...lista.map((p, i) => criarCard(p, { n: i })))
}

function atualizarStats() {
  const ps = estado.produtos
  contar('#st-total', ps.length)
  contar('#st-destaque', ps.filter((p) => p.vendeu_muito).length)
  contar('#st-baixo', ps.filter((p) => p.estoque <= ESTOQUE_BAIXO).length)
  contar(
    '#st-valor',
    ps.reduce((soma, p) => soma + p.preco * p.estoque, 0),
    dinheiroCurto,
  )
}

function atualizarCategorias() {
  const nomes = [...new Set(estado.produtos.map((p) => p.categoria))].sort(
    (a, b) => a.localeCompare(b, 'pt-BR'),
  )
  if (!nomes.includes(estado.filtros.categoria)) estado.filtros.categoria = ''
  // O formulário sugere as categorias que já existem, evitando "Informática" e "informatica" separadas.
  $('#categorias').replaceChildren(
    ...nomes.map((n) => h('option', { value: n })),
  )
  $('#sugestoes').replaceChildren(
    ...nomes.map((n) =>
      h(
        'button',
        {
          type: 'button',
          class: 'mini',
          onclick: () => {
            campos.cat.value = n
            atualizarPreview()
            campos.cat.focus()
          },
        },
        n,
      ),
    ),
  )
}

// A API devolve { data, page, limit, total }. Junta todas as páginas numa lista só.
async function buscarTodosProdutos() {
  const todos = []
  for (let pagina = 1; pagina <= 50; pagina++) {
    const resposta = await api(`/produtos?page=${pagina}&limit=100`)
    if (Array.isArray(resposta)) return resposta // formato antigo da API
    const lote = resposta.data ?? []
    todos.push(...lote)
    if (lote.length === 0 || todos.length >= (resposta.total ?? 0)) break
  }
  return todos
}

async function carregar({ silencioso = false } = {}) {
  if (!silencioso) {
    $('#lista').replaceChildren(
      ...Array.from({ length: 6 }, () => h('div', { class: 'esqueleto' })),
    )
    $('#resumo').textContent = 'Carregando produtos...'
  }
  try {
    const dados = await buscarTodosProdutos()
    if (!Array.isArray(dados)) {
      console.error('Resposta inesperada de /produtos:', dados)
      throw new Error(
        'O servidor respondeu num formato inesperado. Confira se a API certa está rodando na porta 3000.',
      )
    }
    estado.produtos = dados
    estado.carregado = true
    atualizarCategorias()
    atualizarStats()
    sanearCarrinho()
    render({ entrada: !silencioso })
  } catch (erro) {
    if (silencioso) {
      toast(erro.message, 'erro')
      return
    }
    $('#resumo').textContent = ''
    $('#lista').replaceChildren(
      h(
        'div',
        { class: 'aviso' },
        h('strong', {}, 'Não foi possível carregar os produtos'),
        erro.message,
        h(
          'div',
          {},
          h(
            'button',
            { type: 'button', onclick: () => carregar() },
            'Tentar de novo',
          ),
        ),
      ),
    )
  }
}

// Rola até o produto e faz a etiqueta piscar. Se um filtro estiver escondendo ele, limpa os filtros.
function mostrarProduto(id) {
  if (!filtrados().some((p) => p._id === id)) limparFiltros()
  requestAnimationFrame(() => {
    const card = $(`[data-id="${CSS.escape(id)}"]`)
    if (!card) return
    card.scrollIntoView({
      behavior: reduzMovimento ? 'auto' : 'smooth',
      block: 'center',
    })
    card.classList.add('piscar')
    setTimeout(() => card.classList.remove('piscar'), 2400)
  })
}

// ---------- conta ----------
function atualizarConta() {
  const logado = Boolean(estado.token && estado.usuario)
  $('#btn-entrar').hidden = logado
  $('#btn-sair').hidden = !logado
  $('#btn-carrinho').hidden = !logado
  $('#btn-pedidos').hidden = !logado
  $('#usuario').hidden = !logado
  if (logado) {
    $('#avatar').textContent = (estado.usuario.nome || '?')
      .trim()
      .charAt(0)
      .toUpperCase()
    $('#u-nome').textContent = estado.usuario.nome
    $('#u-tipo').textContent = ehAdmin() ? 'Administrador' : 'Cliente'
  }
  $('#hero-titulo').textContent = logado
    ? `Olá, ${estado.usuario.nome.trim().split(' ')[0]}!`
    : 'Estoque de produtos'
  $('#hero-sub').textContent = ehAdmin()
    ? 'Você é administrador: gerencie produtos e o status dos pedidos por aqui.'
    : logado
      ? 'Adicione produtos ao carrinho, finalize o pedido e acompanhe o status.'
      : 'Veja o que há no estoque. Entre para comprar ou gerenciar produtos.'

  $('#painel').hidden = !ehAdmin()
  if (!ehAdmin()) resetarForm()
  carregarCarrinho()
  if (estado.carregado) sanearCarrinho()
  else atualizarCarrinhoUI()
  if (estado.carregado) render()
}

function sair() {
  estado.token = null
  estado.usuario = null
  localStorage.removeItem('token')
  if (dlgGaveta.open) dlgGaveta.close()
  atualizarConta()
}

// ---------- login ----------
const dlgLogin = $('#dlg-login')
let timerLogin

$('#btn-entrar').addEventListener('click', () => {
  $('#l-erro').hidden = true
  dlgLogin.showModal()
})
$('#btn-sair').addEventListener('click', () => {
  sair()
  toast('Você saiu da conta.', 'info')
})

$('#btn-olho').addEventListener('click', () => {
  const mostrar = $('#l-senha').type === 'password'
  $('#l-senha').type = mostrar ? 'text' : 'password'
  $('#btn-olho').innerHTML = SVG[mostrar ? 'olhoFechado' : 'olho']
  $('#btn-olho').setAttribute('aria-pressed', String(mostrar))
  $('#btn-olho').setAttribute(
    'aria-label',
    mostrar ? 'Ocultar senha' : 'Mostrar senha',
  )
})
$('#btn-olho').innerHTML = SVG.olho

function confete(alvo = $('#confete')) {
  if (reduzMovimento) return
  const cores = ['#ffc93c', '#0e7c66', '#2b5fd9', '#c8372d', '#ffffff']
  alvo.replaceChildren(
    ...Array.from({ length: 34 }, (_, i) => {
      const pedaco = h('i')
      pedaco.style.cssText = `--x:${(Math.random() - 0.5) * 360}px;--y:${-70 - Math.random() * 150}px;--r:${Math.random() * 720 - 360}deg;--d:${Math.random() * 150}ms;background:${cores[i % cores.length]}`
      return pedaco
    }),
  )
}

function mostrarSucessoLogin(mensagem, usuario) {
  $('#ok-msg').textContent = mensagem
  $('#ok-nome').textContent = `Bem-vindo(a), ${usuario.nome}!`
  $('#form-login').hidden = true
  $('#login-ok').hidden = false
  confete()
  $('#btn-continuar').focus()
  timerLogin = setTimeout(() => dlgLogin.close(), 2200)
}

let modoCadastro = false
function definirModo(cadastro) {
  modoCadastro = cadastro
  $('#campo-nome').hidden = !cadastro
  $('#l-nome').required = cadastro
  $('#l-senha').autocomplete = cadastro ? 'new-password' : 'current-password'
  $('#login-titulo').textContent = cadastro ? 'Criar conta' : 'Entrar'
  $('#login-sub').textContent = cadastro
    ? 'Leva menos de um minuto. A senha precisa ter 6 caracteres ou mais.'
    : 'Use o email e a senha da sua conta.'
  $('#btn-login .rot').textContent = cadastro ? 'Criar conta' : 'Entrar'
  $('#alt-txt').textContent = cadastro ? 'Já tem conta?' : 'Ainda não tem conta?'
  $('#btn-alternar').textContent = cadastro ? 'Entrar' : 'Criar conta'
  $('#l-erro').hidden = true
}
$('#btn-alternar').addEventListener('click', () => {
  definirModo(!modoCadastro)
  $(modoCadastro ? '#l-nome' : '#l-email').focus()
})

function erroNoLogin(texto) {
  $('#l-erro').textContent = texto
  $('#l-erro').hidden = false
  dlgLogin.classList.add('tremer')
  dlgLogin.addEventListener(
    'animationend',
    () => dlgLogin.classList.remove('tremer'),
    { once: true },
  )
}

$('#form-login').addEventListener('submit', async (evento) => {
  evento.preventDefault()
  const botao = $('#btn-login')
  const criando = modoCadastro
  const email = $('#l-email').value.trim()
  const senha = $('#l-senha').value
  $('#l-erro').hidden = true
  if (criando && senha.length < 6)
    return erroNoLogin('A senha deve ter pelo menos 6 caracteres.')

  ocupado(botao, true, criando ? 'Criando conta' : 'Entrando')
  let dados
  try {
    if (criando)
      await api('/usuarios', {
        method: 'POST',
        body: JSON.stringify({ nome: $('#l-nome').value.trim(), email, senha }),
      })
    dados = await api('/login', {
      method: 'POST',
      body: JSON.stringify({ email, senha }),
    })
  } catch (erro) {
    return erroNoLogin(erro.message)
  } finally {
    ocupado(botao, false)
  }

  const usuario = dados.usuario ?? usuarioDoToken(dados.token)
  if (!dados.token || !usuario)
    return erroNoLogin('O servidor respondeu algo inesperado. Tente de novo.')
  estado.token = dados.token
  estado.usuario = {
    nome: usuario.nome,
    email: usuario.email,
    tipo: usuario.tipo,
  }
  localStorage.setItem('token', dados.token)
  atualizarConta()
  mostrarSucessoLogin(
    criando ? 'Conta criada com sucesso' : dados.mensagem || 'Login realizado com sucesso',
    estado.usuario,
  )
})

$('#btn-continuar').addEventListener('click', () => dlgLogin.close())
dlgLogin.addEventListener('close', () => {
  clearTimeout(timerLogin)
  const entrou = !$('#login-ok').hidden
  $('#login-ok').hidden = true
  $('#form-login').hidden = false
  $('#form-login').reset()
  definirModo(false)
  $('#l-senha').type = 'password'
  $('#btn-olho').innerHTML = SVG.olho
  if (entrou) toast('Login realizado com sucesso!', 'ok')
})

// ---------- cadastro e edição de produtos ----------
const campos = {
  nome: $('#p-nome'),
  preco: $('#p-preco'),
  estoque: $('#p-estoque'),
  cat: $('#p-cat'),
  destaque: $('#p-destaque'),
}

function atualizarPreview() {
  const preco = Number(campos.preco.value)
  $('#preview').replaceChildren(
    criarCard(
      {
        nome: campos.nome.value.trim() || 'Nome do produto',
        preco: Number.isFinite(preco) ? preco : 0,
        categoria: campos.cat.value.trim() || 'Categoria',
        estoque:
          campos.estoque.value === '' ? null : Number(campos.estoque.value),
        vendeu_muito: campos.destaque.checked,
      },
      { preview: true },
    ),
  )
}

function modoFormulario() {
  const editando = Boolean(estado.editandoId)
  $('#painel').classList.toggle('editando', editando)
  $('#painel-titulo').textContent = editando
    ? 'Editar produto'
    : 'Cadastrar produto'
  $('#painel-sub').textContent = editando
    ? 'Altere o que precisar e salve. A etiqueta ao lado mostra como vai ficar.'
    : 'Preencha os dados e veja a etiqueta ao vivo.'
  $('#btn-salvar .rot').textContent = editando
    ? 'Salvar alterações'
    : 'Cadastrar produto'
  $('#btn-cancelar').textContent = editando ? 'Cancelar edição' : 'Limpar'
}

function resetarForm() {
  const estavaEditando = Boolean(estado.editandoId)
  estado.editandoId = null
  $('#form-produto').reset()
  $('#p-erro').hidden = true
  modoFormulario()
  atualizarPreview()
  if (estavaEditando && estado.carregado) render()
}

function abrirProduto(produto) {
  estado.editandoId = produto._id
  campos.nome.value = produto.nome
  campos.preco.value = produto.preco
  campos.estoque.value = produto.estoque
  campos.cat.value = produto.categoria
  campos.destaque.checked = Boolean(produto.vendeu_muito)
  $('#p-erro').hidden = true
  $('#painel-corpo').hidden = false
  $('#btn-recolher').setAttribute('aria-expanded', 'true')
  $('#btn-recolher .rot').textContent = 'Recolher'
  modoFormulario()
  atualizarPreview()
  render()
  $('#painel').scrollIntoView({
    behavior: reduzMovimento ? 'auto' : 'smooth',
    block: 'start',
  })
  campos.nome.focus({ preventScroll: true })
}

for (const campo of Object.values(campos))
  campo.addEventListener('input', atualizarPreview)
$('#btn-cancelar').addEventListener('click', resetarForm)
$$('[data-passo]').forEach((botao) =>
  botao.addEventListener('click', () => {
    campos.estoque.value = Math.max(
      0,
      (Number(campos.estoque.value) || 0) + Number(botao.dataset.passo),
    )
    atualizarPreview()
  }),
)
$('#btn-recolher').addEventListener('click', () => {
  const corpo = $('#painel-corpo')
  corpo.hidden = !corpo.hidden
  $('#btn-recolher').setAttribute('aria-expanded', String(!corpo.hidden))
  $('#btn-recolher .rot').textContent = corpo.hidden ? 'Expandir' : 'Recolher'
})

$('#form-produto').addEventListener('submit', async (evento) => {
  evento.preventDefault()
  const botao = $('#btn-salvar')
  const editando = estado.editandoId
  // Se a categoria já existe com outra caixa ("informatica" x "Informática"), usa a que já existe.
  const digitada = campos.cat.value.trim()
  const existente = estado.produtos.find(
    (p) => normalizar(p.categoria) === normalizar(digitada),
  )
  const corpo = {
    nome: campos.nome.value.trim(),
    preco: Number(campos.preco.value),
    estoque: Number(campos.estoque.value),
    categoria: existente ? existente.categoria : digitada,
    vendeu_muito: campos.destaque.checked,
  }

  $('#p-erro').hidden = true
  ocupado(botao, true, editando ? 'Salvando' : 'Cadastrando')
  let salvo
  try {
    salvo = await api(editando ? `/produtos/${editando}` : '/produtos', {
      method: editando ? 'PUT' : 'POST',
      body: JSON.stringify(corpo),
    })
  } catch (erro) {
    $('#p-erro').textContent = erro.message
    $('#p-erro').hidden = false
    return
  } finally {
    ocupado(botao, false)
  }

  resetarForm()
  await carregar({ silencioso: true })
  if (editando) {
    toast(`“${salvo.nome}” foi atualizado.`)
    mostrarProduto(salvo._id)
  } else {
    toast(`“${salvo.nome}” cadastrado com sucesso!`, 'ok', {
      rotulo: 'Ver na lista',
      fn: () => mostrarProduto(salvo._id),
    })
    campos.nome.focus() // pronto para cadastrar o próximo
  }
})

// Excluir pede um segundo clique para confirmar (volta ao normal em 3 segundos).
function confirmarExclusao(botao, produto) {
  const rot = botao.querySelector('.rot')
  if (!botao.classList.contains('armado')) {
    botao.classList.add('armado')
    rot.textContent = 'Confirmar?'
    botao._timer = setTimeout(() => {
      botao.classList.remove('armado')
      rot.textContent = 'Excluir'
    }, 3000)
    return
  }
  clearTimeout(botao._timer)
  botao.disabled = true
  api(`/produtos/${produto._id}`, { method: 'DELETE' })
    .then(async () => {
      if (estado.editandoId === produto._id) resetarForm()
      await carregar({ silencioso: true })
      toast(`“${produto.nome}” foi excluído.`, 'info')
    })
    .catch((erro) => {
      botao.disabled = false
      toast(erro.message, 'erro')
    })
}

// ---------- carrinho ----------
const dlgGaveta = $('#dlg-gaveta')
const chaveCarrinho = () => `carrinho:${estado.usuario?.email ?? ''}`
const produtoPorId = (id) => estado.produtos.find((p) => p._id === id)

function salvarCarrinho() {
  if (!estado.usuario) return
  try {
    localStorage.setItem(chaveCarrinho(), JSON.stringify([...estado.carrinho]))
  } catch {}
}
function carregarCarrinho() {
  estado.carrinho = new Map()
  if (!estado.usuario) return
  try {
    for (const [id, q] of JSON.parse(localStorage.getItem(chaveCarrinho()) || '[]'))
      if (Number(q) > 0) estado.carrinho.set(id, Number(q))
  } catch {}
}
// Remove do carrinho o que sumiu do estoque e ajusta quantidades acima do disponível.
function sanearCarrinho() {
  let mudou = false
  for (const [id, q] of estado.carrinho) {
    const p = produtoPorId(id)
    if (!p || p.estoque < 1) {
      estado.carrinho.delete(id)
      mudou = true
    } else if (q > p.estoque) {
      estado.carrinho.set(id, p.estoque)
      mudou = true
    }
  }
  if (mudou) salvarCarrinho()
  atualizarCarrinhoUI()
}
const itensCarrinho = () =>
  [...estado.carrinho]
    .map(([id, qtd]) => ({ p: produtoPorId(id), qtd }))
    .filter((i) => i.p)
const qtdCarrinho = () => [...estado.carrinho.values()].reduce((s, q) => s + q, 0)
const totalCarrinho = () => itensCarrinho().reduce((s, i) => s + i.p.preco * i.qtd, 0)

function atualizarCarrinhoUI(pulsar = false) {
  const n = qtdCarrinho()
  const badge = $('#carrinho-qtd')
  badge.textContent = n > 99 ? '99+' : String(n)
  badge.hidden = n === 0
  if (pulsar && !reduzMovimento) {
    badge.classList.remove('bump')
    void badge.offsetWidth // reinicia a animação
    badge.classList.add('bump')
  }
  $('#aba-qtd').textContent = String(n)
  $('#aba-qtd').hidden = n === 0
  if (dlgGaveta.open && estado.aba === 'carrinho' && !estado.finalizado) renderCarrinho()
}

function pedirLogin() {
  toast('Entre na sua conta para comprar.', 'info')
  $('#btn-entrar').click()
}

function mudarQtd(p, delta) {
  const atual = estado.carrinho.get(p._id) ?? 0
  if (delta > 0 && atual >= p.estoque) {
    toast(`Só temos ${p.estoque} unidade${p.estoque === 1 ? '' : 's'} de “${p.nome}”.`, 'info')
    return
  }
  const nova = Math.max(0, Math.min(p.estoque, atual + delta))
  if (nova === 0) estado.carrinho.delete(p._id)
  else estado.carrinho.set(p._id, nova)
  estado.erroCarrinho = ''
  salvarCarrinho()
  atualizarCarrinhoUI(delta > 0)
  render()
}
function adicionar(p) {
  if (!estado.token) return pedirLogin()
  mudarQtd(p, 1)
}

// Botões − e + usados no card do produto e no carrinho.
function controleQtd(p, qtd) {
  return h(
    'div',
    { class: 'qtd-ctl' },
    h('button', { type: 'button', 'aria-label': `Diminuir ${p.nome}`, onclick: () => mudarQtd(p, -1) }, icone('menos')),
    h('output', { 'aria-live': 'polite' }, String(qtd)),
    h('button', { type: 'button', 'aria-label': `Aumentar ${p.nome}`, onclick: () => mudarQtd(p, 1) }, icone('mais')),
  )
}

// ---------- gaveta: carrinho e pedidos ----------
function abrirGaveta(aba = 'carrinho') {
  if (!estado.token) return pedirLogin()
  if (!dlgGaveta.open) dlgGaveta.showModal()
  trocarAba(aba)
}
function trocarAba(aba) {
  estado.aba = aba
  estado.finalizado = false
  estado.erroCarrinho = ''
  $$('[data-aba]').forEach((b) => b.setAttribute('aria-selected', String(b.dataset.aba === aba)))
  if (aba === 'carrinho') renderCarrinho()
  else renderPedidos()
  $('#gaveta-corpo').scrollTop = 0
}

function vazioGaveta(titulo, texto, botao) {
  return h(
    'div',
    { class: 'vazio-gaveta' },
    h('span', { class: 'bolha azul grande' }, icone(botao.ico)),
    h('strong', {}, titulo),
    h('p', {}, texto),
    h('button', { type: 'button', onclick: botao.fn }, botao.rotulo),
  )
}

function renderCarrinho() {
  const itens = itensCarrinho()
  const corpo = $('#gaveta-corpo')
  const rodape = $('#gaveta-rodape')
  if (!itens.length) {
    rodape.hidden = true
    corpo.replaceChildren(
      vazioGaveta('Seu carrinho está vazio', 'Adicione produtos da lista para montar seu pedido.', {
        ico: 'carrinho',
        rotulo: 'Ver produtos',
        fn: () => dlgGaveta.close(),
      }),
    )
    return
  }

  corpo.replaceChildren(
    h(
      'ul',
      { class: 'itens' },
      ...itens.map(({ p, qtd }, i) => {
        const li = h(
          'li',
          { class: 'item', style: `--h:${matizDaCategoria(p.categoria)};--n:${Math.min(i, 8)}` },
          h('span', { class: 'mini-tag', 'aria-hidden': 'true' }, p.nome.trim().charAt(0).toUpperCase()),
          h(
            'div',
            { class: 'item-info' },
            h('strong', {}, p.nome),
            h('small', {}, `${dinheiro(p.preco)} cada · ${p.estoque} em estoque`),
          ),
          h(
            'div',
            { class: 'item-dir' },
            h('b', {}, dinheiro(p.preco * qtd)),
            controleQtd(p, qtd),
          ),
        )
        return li
      }),
    ),
    h(
      'button',
      {
        type: 'button',
        class: 'link',
        onclick: () => {
          estado.carrinho.clear()
          estado.erroCarrinho = ''
          salvarCarrinho()
          atualizarCarrinhoUI()
          render()
        },
      },
      'Esvaziar carrinho',
    ),
  )

  const erro = h('p', { class: 'msg-erro', role: 'alert' }, estado.erroCarrinho)
  erro.hidden = !estado.erroCarrinho
  const n = qtdCarrinho()
  rodape.replaceChildren(
    h(
      'div',
      { class: 'total' },
      h('span', {}, `${n} ${n === 1 ? 'item' : 'itens'}`),
      h('strong', {}, dinheiro(totalCarrinho())),
    ),
    erro,
    h(
      'button',
      {
        type: 'button',
        class: 'finalizar',
        onclick: (e) => finalizarPedido(e.currentTarget),
      },
      icone('recibo'),
      h('span', { class: 'rot' }, 'Finalizar pedido'),
    ),
  )
  rodape.hidden = false
}

const CHECK_SVG =
  '<svg class="check" viewBox="0 0 52 52" aria-hidden="true"><circle cx="26" cy="26" r="24" fill="none"/><path d="M14 27l8 8 16-17" fill="none"/></svg>'

async function finalizarPedido(botao) {
  const itens = [...estado.carrinho].map(([produtoId, quantidade]) => ({ produtoId, quantidade }))
  if (!itens.length) return
  estado.erroCarrinho = ''
  ocupado(botao, true, 'Enviando pedido')
  let pedido
  try {
    pedido = await api('/pedidos', { method: 'POST', body: JSON.stringify({ itens }) })
  } catch (erro) {
    estado.erroCarrinho = erro.message
    renderCarrinho()
    carregar({ silencioso: true }) // o estoque pode ter mudado
    return
  } finally {
    ocupado(botao, false)
  }

  estado.finalizado = true
  estado.carrinho.clear()
  salvarCarrinho()
  atualizarCarrinhoUI()
  carregar({ silencioso: true })
  mostrarSucessoPedido(pedido)
}

function mostrarSucessoPedido(pedido) {
  $('#gaveta-rodape').hidden = true
  const confeteEl = h('div', { class: 'confete', 'aria-hidden': 'true' })
  const check = h('span', { class: 'check-box' })
  check.innerHTML = CHECK_SVG
  $('#gaveta-corpo').replaceChildren(
    h(
      'div',
      { class: 'sucesso', role: 'status' },
      confeteEl,
      check,
      h('h2', {}, 'Pedido realizado!'),
      h(
        'p',
        {},
        `Pedido #${codigoPedido(pedido)} no valor de ${dinheiro(pedido.total ?? 0)}. Agora é só aguardar o pagamento.`,
      ),
      h('button', { type: 'button', onclick: () => trocarAba('pedidos') }, 'Acompanhar pedido'),
      h('button', { type: 'button', class: 'sec', onclick: () => dlgGaveta.close() }, 'Continuar comprando'),
    ),
  )
  confete(confeteEl)
}

// ---------- pedidos ----------
const STATUS = {
  pendente: { rot: 'Aguardando pagamento', curto: 'Pedido feito', ico: 'relogio' },
  pago: { rot: 'Pago', curto: 'Pago', ico: 'cartao' },
  enviado: { rot: 'Enviado', curto: 'Enviado', ico: 'caminhao' },
  cancelado: { rot: 'Cancelado', curto: 'Cancelado', ico: 'x' },
}
const ETAPAS = ['pendente', 'pago', 'enviado']
const codigoPedido = (pd) => String(pd._id ?? '').slice(-6).toUpperCase()
const dataPedido = (pd) =>
  pd.createdAt
    ? new Date(pd.createdAt).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })
    : ''

async function copiarTexto(texto) {
  try {
    await navigator.clipboard.writeText(texto)
    toast('ID do pedido copiado.')
  } catch {
    toast(`Não consegui copiar. ID: ${texto}`, 'info')
  }
}

function repetirPedido(pd) {
  const faltando = []
  let adicionados = 0
  for (const item of pd.itens) {
    const p = produtoPorId(item.produto)
    if (!p || p.estoque < 1) {
      faltando.push(item.nome)
      continue
    }
    const nova = Math.min(p.estoque, (estado.carrinho.get(p._id) ?? 0) + item.quantidade)
    estado.carrinho.set(p._id, nova)
    adicionados++
  }
  salvarCarrinho()
  atualizarCarrinhoUI(true)
  render()
  if (faltando.length) toast(`Sem estoque agora: ${faltando.join(', ')}.`, 'info')
  else toast('Itens adicionados ao carrinho.')
  if (adicionados) trocarAba('carrinho')
}

async function mudarStatus(pd, status, card, botao) {
  if (pd.status === status) return
  botao.disabled = true
  try {
    const novo = await api(`/pedidos/${pd._id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    })
    pd.status = novo.status ?? status
    card.replaceWith(cardPedido(pd))
    toast(`Pedido #${codigoPedido(pd)}: ${STATUS[pd.status].rot.toLowerCase()}.`)
  } catch (erro) {
    botao.disabled = false
    toast(erro.message, 'erro')
  }
}

function cardPedido(pd, { n = 0 } = {}) {
  const st = STATUS[pd.status] ?? STATUS.pendente
  const itens = pd.itens ?? []
  const qtd = itens.reduce((s, i) => s + i.quantidade, 0)
  const atual = ETAPAS.indexOf(pd.status)

  const card = h(
    'article',
    { class: 'pedido', style: `--n:${Math.min(n, 8)}` },
    h(
      'div',
      { class: 'pedido-topo' },
      h('div', {}, h('strong', {}, `Pedido #${codigoPedido(pd)}`), h('small', {}, dataPedido(pd))),
      h('span', { class: `status s-${pd.status}` }, icone(st.ico), st.rot),
    ),
    pd.status === 'cancelado'
      ? h('p', { class: 'cancelado-aviso' }, 'Este pedido foi cancelado.')
      : h(
          'ol',
          { class: 'etapas' },
          ...ETAPAS.map((e, i) =>
            h(
              'li',
              { class: `etapa${i <= atual ? ' feita' : ''}${i === atual ? ' atual' : ''}` },
              h('span', { class: 'bola' }, icone(STATUS[e].ico)),
              h('span', {}, STATUS[e].curto),
            ),
          ),
        ),
    h(
      'details',
      { class: 'itens-det' },
      h('summary', {}, `${qtd} ${qtd === 1 ? 'item' : 'itens'}`),
      h(
        'ul',
        {},
        ...itens.map((i) =>
          h('li', {}, h('span', {}, `${i.quantidade}× ${i.nome}`), h('b', {}, dinheiro(i.subtotal))),
        ),
      ),
    ),
    h('div', { class: 'pedido-total' }, h('span', {}, 'Total'), h('strong', {}, dinheiro(pd.total))),
    h(
      'div',
      { class: 'pedido-acoes' },
      h(
        'button',
        { type: 'button', class: 'sec pequeno', onclick: () => repetirPedido(pd) },
        icone('refazer'),
        h('span', { class: 'rot' }, 'Repetir'),
      ),
      h(
        'button',
        { type: 'button', class: 'sec pequeno', onclick: () => copiarTexto(pd._id), title: 'Copiar ID do pedido' },
        icone('copiar'),
        h('span', { class: 'rot' }, 'Copiar ID'),
      ),
    ),
  )

  if (ehAdmin()) {
    card.append(
      h(
        'div',
        { class: 'status-admin' },
        h('small', {}, 'Alterar status'),
        h(
          'div',
          { class: 'status-botoes' },
          ...Object.keys(STATUS).map((s) =>
            h(
              'button',
              {
                type: 'button',
                class: 'mini',
                'aria-pressed': String(pd.status === s),
                onclick: (e) => mudarStatus(pd, s, card, e.currentTarget),
              },
              STATUS[s].rot,
            ),
          ),
        ),
      ),
    )
  }
  return card
}

// O back só deixa o admin consultar um pedido de cada vez, pelo ID.
function buscaAdmin() {
  const resultado = h('div', { class: 'resultado-admin' })
  const campo = h('input', {
    placeholder: 'Cole o ID do pedido (24 caracteres)',
    maxlength: '24',
    autocomplete: 'off',
    'aria-label': 'ID do pedido',
  })
  const botao = h('button', { type: 'submit', class: 'pequeno' }, icone('lupa'), h('span', { class: 'rot' }, 'Buscar'))
  const form = h(
    'form',
    {
      class: 'busca-admin',
      onsubmit: async (e) => {
        e.preventDefault()
        const id = campo.value.trim()
        if (!/^[a-f0-9]{24}$/i.test(id)) {
          resultado.replaceChildren(h('p', { class: 'msg-erro' }, 'O ID precisa ter 24 caracteres (letras de a-f e números).'))
          return
        }
        ocupado(botao, true, 'Buscando')
        try {
          resultado.replaceChildren(cardPedido(await api(`/pedidos/${id}`)))
        } catch (erro) {
          resultado.replaceChildren(h('p', { class: 'msg-erro' }, erro.message))
        } finally {
          ocupado(botao, false)
        }
      },
    },
    campo,
    botao,
  )
  return h('section', { class: 'caixa-admin' }, h('p', { class: 'kicker' }, 'Admin · buscar pedido'), form, resultado)
}

async function renderPedidos() {
  $('#gaveta-rodape').hidden = true
  const lista = h('div', { class: 'pedidos' }, h('div', { class: 'esqueleto pequeno' }), h('div', { class: 'esqueleto pequeno' }))
  $('#gaveta-corpo').replaceChildren(...(ehAdmin() ? [buscaAdmin()] : []), h('p', { class: 'kicker' }, 'Meus pedidos'), lista)
  try {
    const dados = await api('/meus-pedidos')
    if (estado.aba !== 'pedidos') return
    estado.pedidos = Array.isArray(dados) ? dados : []
    lista.replaceChildren(
      ...(estado.pedidos.length
        ? estado.pedidos.map((pd, i) => cardPedido(pd, { n: i }))
        : [
            vazioGaveta('Nenhum pedido ainda', 'Quando você finalizar uma compra, ela aparece aqui.', {
              ico: 'recibo',
              rotulo: 'Ver produtos',
              fn: () => dlgGaveta.close(),
            }),
          ]),
    )
  } catch (erro) {
    if (estado.aba !== 'pedidos') return
    lista.replaceChildren(
      h(
        'div',
        { class: 'aviso' },
        h('strong', {}, 'Não foi possível carregar seus pedidos'),
        erro.message,
        h('div', {}, h('button', { type: 'button', onclick: renderPedidos }, 'Tentar de novo')),
      ),
    )
  }
}

$('#btn-carrinho').addEventListener('click', () => abrirGaveta('carrinho'))
$('#btn-pedidos').addEventListener('click', () => abrirGaveta('pedidos'))
$$('[data-aba]').forEach((b) => b.addEventListener('click', () => trocarAba(b.dataset.aba)))
dlgGaveta.addEventListener('close', () => {
  estado.finalizado = false
})

// ---------- eventos gerais ----------
$$('[data-fechar]').forEach((b) =>
  b.addEventListener('click', () => b.closest('dialog').close()),
)
// Clicar fora da janela fecha.
for (const dlg of $$('dialog'))
  dlg.addEventListener('click', (e) => {
    if (e.target !== dlg) return
    const r = dlg.getBoundingClientRect()
    if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom)
      dlg.close()
  })

for (const id of ['#busca', '#ordem'])
  $(id).addEventListener('input', () => render())
$('#btn-limpar').addEventListener('click', limparFiltros)
for (const [id, chave] of [
  ['#st-destaque-btn', 'destaque'],
  ['#st-baixo-btn', 'baixo'],
]) {
  $(id).addEventListener('click', () => {
    estado.filtros[chave] = !estado.filtros[chave]
    render()
    $('.barra').scrollIntoView({
      behavior: reduzMovimento ? 'auto' : 'smooth',
      block: 'start',
    })
  })
}
$('#st-baixo-btn').title =
  `${ESTOQUE_BAIXO} unidades ou menos. Clique para filtrar.`
$('#st-destaque-btn').title = 'Clique para filtrar os que vendem muito.'

// "/" leva direto para a busca.
document.addEventListener('keydown', (e) => {
  if (e.key !== '/' || e.ctrlKey || e.metaKey || e.altKey) return
  if (
    document.querySelector('dialog[open]') ||
    /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName)
  )
    return
  e.preventDefault()
  $('#busca').focus()
})

// "C" abre o carrinho.
document.addEventListener('keydown', (e) => {
  if (e.key.toLowerCase() !== 'c' || e.ctrlKey || e.metaKey || e.altKey) return
  if (
    !estado.token ||
    document.querySelector('dialog[open]') ||
    /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName)
  )
    return
  e.preventDefault()
  abrirGaveta('carrinho')
})

restaurarSessao()
atualizarConta()
carregar()
